﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DependencyInjMVC.Repository
{
   public interface ISchemeRepository
    {
        IEnumerable<Scheme> GetAll();
       Scheme Get(int id);
        Scheme Add(Scheme item);
        bool Update(Scheme item);
        bool Delete(int id);
    }
}

