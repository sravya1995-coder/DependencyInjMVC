﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using DependencyInjMVC.Repository;

namespace DependencyInjMVC.Repository
{
    public class UserMasterRepository : IUserMasterRepository
    {
        private List<UserMaster> users = new List<UserMaster>();
        private int Id = 1;

        public UserMasterRepository()
        {
            // Add products for the Demonstration  
            Add(new UserMaster { SchemeName = "Soft Loan", EmailID = "user1@test.com", Rules = "Age should be above 20 "});
            Add(new UserMaster { SchemeName = "Loan with Interest", EmailID = "user2@test.com", Rules = "Age should be above 30" });
            Add(new UserMaster { SchemeName = "Loan without interest", EmailID = "user3@test.com", Rules = "Age should be above 20 " });
        }

        public UserMaster Add(UserMaster item)
        {
            if (item == null)
            {
                throw new ArgumentNullException("item");
            }

            item.SchemeID = Id++;
            users.Add(item);
            return item;
        }

        public bool Delete(int id)
        {
            users.RemoveAll(p => p.SchemeID == id);
            return true;
        }

        public UserMaster Get(int id)
        {
            return users.FirstOrDefault(x => x.SchemeID == id);
        }

        public IEnumerable<UserMaster> GetAll()
        {
            return users;
        }

        public bool Update(UserMaster item)
        {
            if (item == null)
            {
                throw new ArgumentNullException("item");
            }


            int index = users.FindIndex(p => p.SchemeID == item.SchemeID);
            if (index == -1)
            {
                return false;
            }
            users.RemoveAt(index);
            users.Add(item);
            return true;
        }
    }
}

