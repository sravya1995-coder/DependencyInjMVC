﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace DependencyInjMVC.Repository
{
    public class UserMaster
    {
       
        public int SchemeID { get; set; }
        public string SchemeName { get; set; }

        public string EmailID { get; set; }

        public string Rules { get; set; }
    }
}