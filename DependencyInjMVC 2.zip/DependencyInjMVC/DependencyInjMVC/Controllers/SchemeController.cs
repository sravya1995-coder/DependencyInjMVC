﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using DependencyInjMVC.Repository;

namespace DependencyInjMVC.Controllers
{
    public class SchemeController : Controller
    {
        readonly IUserMasterRepository userRepository;
        public SchemeController(IUserMasterRepository repository)
        {
            this.userRepository = repository;
        }
        // GET: User  
        public ActionResult Index()
        {
            var data = userRepository.GetAll();
            return View(data);
        }
    
    
        // GET: Scheme/Details/5
        public ActionResult Details(int id)
        {
            return View();
        }

        // GET: Scheme/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Scheme/Create
        [HttpPost]
        public ActionResult Create(FormCollection collection)
        {
            try
            {
                // TODO: Add insert logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: Scheme/Edit/5
        public ActionResult Edit(int id)
        {
            return View();
        }

        // POST: Scheme/Edit/5
        [HttpPost]
        public ActionResult Edit(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add update logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: Scheme/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: Scheme/Delete/5
        [HttpPost]
        public ActionResult Delete(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add delete logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }
    }
}
